import { Component, OnInit } from '@angular/core';
import { BillingService, Bill } from './billing.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-billing',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.scss']
})
export class BillingComponent implements OnInit {
  unpaidBills: Bill[] = [];
  selectedBill: Bill | null = null;

  constructor(private billingService: BillingService) {}

  ngOnInit(): void {
    this.loadUnpaidBills();
  }

  loadUnpaidBills(): void {
    this.billingService.getUnpaidBills().subscribe({
      next: bills => this.unpaidBills = bills,
      error: err => console.error('Failed to load bills', err)
    });
  }

  viewBill(bill: Bill): void {
    this.selectedBill = bill;
  }

  markAsPaid(): void {
    if (!this.selectedBill) return;

    this.billingService.markBillAsPaid(this.selectedBill.appointmentId).subscribe({
      next: () => {
        alert('Bill marked as Paid!');
        this.selectedBill = null;
        this.loadUnpaidBills();
      },
      error: err => console.error('Failed to mark as paid', err)
    });
  }

  printBill(): void {
    if (!this.selectedBill) return;

    const bill = this.selectedBill;
    const billWindow = window.open('', '_blank');
    billWindow?.document.write(`
      <html>
        <head><title>Bill</title></head>
        <body style="font-family: Arial; padding: 20px;">
          <h2 style="text-align:center;">Clinic Bill</h2>
          <hr/>
          <p><strong>Doctor:</strong> ${bill.doctorName}</p>
          <p><strong>Patient:</strong> ${bill.patientName}</p>
          <p><strong>Start Time:</strong> ${new Date(bill.startTime).toLocaleString()}</p>
          <p><strong>Duration:</strong> ${bill.duration} minutes</p>
          <p><strong>Clinic Room:</strong> ${bill.clinicRoomNumber}</p>
          <p><strong>Fee:</strong> $${bill.fee.toFixed(2)}</p>
          <p><strong>Status:</strong> ${bill.billStatus}</p>
          <hr/>
          <p style="text-align:center;">Thank you for visiting!</p>
        </body>
      </html>
    `);
    billWindow?.print();
  }
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environment/environemnt';

export interface Bill {
  appointmentId: number;
  doctorName: string;
  patientName: string;
  startTime: string;
  duration: number;
  fee: number;
  clinicRoomNumber: string;
  billStatus: string;
}

@Injectable({
  providedIn: 'root'
})
export class BillingService {
  //private apiUrl = 'https://localhost:5001/api/Billing';
  private apiUrl = environment.apiUrl+"/Billing";

  constructor(private http: HttpClient) {}

  // Helper method to get headers with token
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token') || '';
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  // Get all unpaid bills
  getUnpaidBills(): Observable<Bill[]> {
    return this.http.get<Bill[]>(`${this.apiUrl}/unpaid`, { headers: this.getAuthHeaders() });
  }

  // Get bill by appointment id
  getBillByAppointmentId(id: number): Observable<Bill> {
    return this.http.get<Bill>(`${this.apiUrl}/${id}`, { headers: this.getAuthHeaders() });
  }

  // Mark a bill as paid
  markBillAsPaid(id: number): Observable<string> {
    return this.http.put(`${this.apiUrl}/${id}/pay`, {}, { headers: this.getAuthHeaders(), responseType: 'text' });
  }
}

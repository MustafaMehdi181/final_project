import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environment/environemnt';

export interface Doctor {
  doctorId?: number;
  doctorName: string;
  doctorSpecialty: string;
}

@Injectable({ providedIn: 'root' })
export class DoctorsService {
  //private apiUrl = 'https://localhost:5001/api/Doctors';
  private apiUrl = environment.apiUrl+"/Doctors";

  constructor(private http: HttpClient) {}

  // Helper method to get headers with token
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token') || '';
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  getAll(): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(this.apiUrl, { headers: this.getAuthHeaders() });
  }

  add(doctor: Doctor): Observable<any> {
    return this.http.post(this.apiUrl, doctor, { headers: this.getAuthHeaders() });
  }

  update(doctor: Doctor): Observable<any> {
    return this.http.put(`${this.apiUrl}/${doctor.doctorId}`, doctor, { headers: this.getAuthHeaders() });
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`, { headers: this.getAuthHeaders() });
  }
}

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService, LoginModel, LoginResponse } from './auth.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule , CommonModule],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  model: LoginModel = { email: '', password: '' };
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
    this.authService.login(this.model).subscribe(
      (res: LoginResponse) => {
        
        // Store the token and role manually
        localStorage.setItem('token', res.token);
        //console.log('token:' , res.accessToken)
        localStorage.setItem('role', res.role);
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.error('Login failed:', err);
        this.errorMessage = 'Invalid login';
      }
    );
  }
}

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService, RegisterModel } from './auth.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule , CommonModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  model: RegisterModel = { email: '', password: '', role: '' };
  errorMessage = '';
  successMessage = '';

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
    this.authService.register(this.model).subscribe({
      next: (res) => {
        this.successMessage = 'User registered successfully.';
        this.errorMessage = '';
        this.router.navigate(['/login']);
      },
      error: (err) => {
        this.errorMessage = 'Registration failed. ' + (err.error?.message || '');
        this.successMessage = '';
        console.error('Registration failed:', err);
      }
    });
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../environment/environemnt';
import { HttpHeaders } from '@angular/common/http';

export interface LoginModel {
  email: string;
  password: string;
}

export interface RegisterModel {
  email: string;
  password: string;
  role: string;
}

export interface LoginResponse {
  token: string;
  role: string;
  refreshToken?: string;  // optional, if backend sends refresh token
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseloginUrl = environment.apiUrl + "/User";
  private baseregUrl = environment.apiUrl + "/Register";

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token') || '';
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  login(model: LoginModel): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.baseloginUrl}/login`, model).pipe(
      tap(res => {
        localStorage.setItem('token', res.token);
        if (res.refreshToken) {
          localStorage.setItem('refreshToken', res.refreshToken);
        }
      })
    );
  }

  register(model: RegisterModel): Observable<any> {
    return this.http.post(`${this.baseregUrl}/register`, model, { headers: this.getAuthHeaders() });
  }
    
  getUserRole(){
      return localStorage.getItem("role")
  }

   hasRole(roles: string[]): boolean {
    const userRole = this.getUserRole();
    return userRole ? roles.includes(userRole) : false;
  }


  refreshToken(): Observable<{ AccessToken: string }> {
    const refreshToken = localStorage.getItem('refresh_token');
    if (!refreshToken) {
      throw new Error('No refresh token stored.');
    }

    // The API expects the raw string in the body, so JSON.stringify the string
    return this.http.post<{ AccessToken: string }>(
      `${environment.apiUrl}/Refresh/refresh`,
      `"${refreshToken}"`,   // send refreshToken as JSON string
      { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }
    ).pipe(
      tap(res => {
        console.log('New access token received:', res.AccessToken);
        localStorage.setItem('token', res.AccessToken);
      })
    );
  }
}

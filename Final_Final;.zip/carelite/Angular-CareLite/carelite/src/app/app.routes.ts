import { Routes } from '@angular/router';
import { LoginComponent } from './auth/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './auth/auth.guard';
import { DoctorsComponent } from './doctors/doctor.component';
import { PatientsComponent } from './patients/patients.component';
import { VisitsComponent } from './visits/visits.component';
import { VisitTypeComponent } from './visit-types/visit-types.components';
import { BillingComponent } from './Billing/billing.coponent';
import { GuestGuard } from './auth/guest.guard';
import { RegisterComponent } from './auth/register.component';
import { RoleGuard } from './auth/role.guard';
import { UnauthorizedComponent } from './auth/unauth.component';

export const routes: Routes = [
  { path: '' , redirectTo:'login',pathMatch:'full'},
  { path: 'login', component: LoginComponent ,canActivate:[GuestGuard]},
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'doctor' , component: DoctorsComponent , canActivate: [AuthGuard ,RoleGuard],
    data:{roles:["admin"]}
  },
  {path : 'patients' , component:PatientsComponent},
  {path: 'visits' , component: VisitsComponent , canActivate: [AuthGuard]},
  {path: 'visittypes' , component: VisitTypeComponent , canActivate: [AuthGuard]},
  {path: 'register-user' , component: RegisterComponent , canActivate: [AuthGuard,RoleGuard],
    data:{roles:["admin"]}
  },
  {path: 'unauthorized' , component: UnauthorizedComponent},
  {path: 'bill' , component: BillingComponent}

];

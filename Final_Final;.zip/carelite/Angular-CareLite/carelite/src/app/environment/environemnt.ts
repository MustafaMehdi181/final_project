export const environment = {
  production: false,
  apiUrl: 'https://localhost:5001/api',
  //apiUrl : 'http://cmdlhrltx329:3001/api'
};

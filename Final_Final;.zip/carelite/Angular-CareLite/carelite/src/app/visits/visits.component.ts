import { Component, OnInit } from '@angular/core';
import { VisitsService, Appointment } from './visits.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-visits',
  standalone: true,
  imports: [CommonModule , FormsModule],
  templateUrl: './visits.html',
  styleUrls: ['./visits.component.scss']
})
export class VisitsComponent implements OnInit {
  appointments: Appointment[] = [];
  filteredAppointments: Appointment[] = [];

  searchKeyword = '';

  newAppointment: Appointment = {
    doctorName: '',
    patientName: '',
    visitId: 0,
    startTime: '',
    duration: 0,
    fee: 0,
    billStatus: 'Unpaid',
    clinicRoomNumber: ''
  };

  constructor(private visitsService: VisitsService) {}

  ngOnInit() {
    this.loadAppointments();
  }

  loadAppointments() {
    this.visitsService.getAppointments().subscribe({
      next: (data) => {
        this.appointments = data;
        this.filteredAppointments = [...this.appointments];
      },
      error: (err) => console.error('Error loading appointments:', err),
    });
  }

  searchAppointments() {
    const keyword = this.searchKeyword.toLowerCase();
    this.filteredAppointments = this.appointments.filter(
      (appt) =>
        appt.doctorName.toLowerCase().includes(keyword) ||
        appt.patientName.toLowerCase().includes(keyword)
    );
  }

  addAppointment() {
    const localDate = new Date(this.newAppointment.startTime);

    // format local datetime (yyyy-MM-ddTHH:mm:ss)
    const formatted = `${localDate.getFullYear()}-${String(localDate.getMonth() + 1).padStart(2, '0')}-${String(localDate.getDate()).padStart(2, '0')}T${String(localDate.getHours()).padStart(2, '0')}:${String(localDate.getMinutes()).padStart(2, '0')}:00`;

    const payload: Appointment = {
      ...this.newAppointment,
      startTime: formatted
    };

    this.visitsService.addAppointment(payload).subscribe({
      next: () => {
        alert('Appointment added successfully');
        this.loadAppointments();
        this.resetForm();
      },
      error: (err) => {
        console.error('Failed to add appointment:', err);
      }
    });
  }

  updateAppointment(appt: Appointment) {
    this.visitsService.updateAppointment(appt).subscribe({
      next: () => {
        alert('Appointment updated');
        this.loadAppointments();
      },
      error: (err) => console.error('Update failed:', err),
    });
  }

  deleteAppointment(id: number) {
    if (confirm('Are you sure you want to delete this appointment?')) {
      this.visitsService.deleteAppointment(id).subscribe({
        next: () => {
          alert('Appointment deleted');
          this.loadAppointments();
        },
        error: (err) => console.error('Delete failed:', err),
      });
    }
  }

  private resetForm() {
    this.newAppointment = {
      doctorName: '',
      patientName: '',
      visitId: 0,
      startTime: '',
      duration: 0,
      fee: 0,
      billStatus: 'Unpaid',
      clinicRoomNumber: ''
    };
  }
}

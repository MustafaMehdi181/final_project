﻿using Microsoft.AspNetCore.SignalR;

namespace carelite.SignalR
{
    public class SignalRhub : Hub
    { 
        public async Task SendReminder(Models.AppointmentInfo appointment)
        {
            await Clients.All.SendAsync("Remindershipped", appointment);
        }
    }
}

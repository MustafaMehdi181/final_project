﻿using System.ComponentModel.DataAnnotations;

namespace carelite.Models

{
    public class Doctor
    {
        public int DoctorId { get; set; }

        [Required(ErrorMessage = "Doctor name is required")]
        [MaxLength(100, ErrorMessage = "Doctor name cannot exceed 100 characters")]
        public string DoctorName { get; set; }

        [Required(ErrorMessage = "Specialty is required")]
        [MaxLength(100, ErrorMessage = "Specialty cannot exceed 100 characters")]
        public string DoctorSpecialty { get; set; }
    }
}

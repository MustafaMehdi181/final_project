﻿using System.ComponentModel.DataAnnotations;

namespace carelite.Models
{
    public class Patient
    {
        public int PatientId { get; set; }

        [Required(ErrorMessage = "Patient name is required")]
        [MaxLength(100, ErrorMessage = "Patient name cannot exceed 100 characters")]
        public string PatientName { get; set; }

        [Required(ErrorMessage = "Phone number is required")]
       public string PatientPhone { get; set; }

        public string Email { get; set; } = string.Empty;
    }
}

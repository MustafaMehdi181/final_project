﻿using System.ComponentModel.DataAnnotations;

namespace carelite.Models
{
    public class VisitType
    {
        public int VisitTypeId { get; set; }

        [Required(ErrorMessage = "Visit type name is required")]
        [MaxLength(100, ErrorMessage = "Visit type name cannot exceed 100 characters")]
        public string VisitTypeName { get; set; }

        [Range(0, 100000, ErrorMessage = "Fee must be a positive number")]
        public decimal Fee { get; set; }
    }
}

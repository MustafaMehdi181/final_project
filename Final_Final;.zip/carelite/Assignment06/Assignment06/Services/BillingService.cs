﻿using carelite.Models;
using carelite.Repositories;


namespace carelite.Services
{
    public class BillingService
    {
        private readonly AppointmentRepository _appointmentRepo;

        public BillingService(AppointmentRepository appointmentRepo)
        {
            _appointmentRepo = appointmentRepo;
        }

        
        public Task<IEnumerable<Bill>> GetUnpaidBillsAsync()
        {
            return Task.Run(() =>
            {
                var appointments = _appointmentRepo.GetAll();
                return appointments
                    .Where(a => a.BillStatus != null &&
                               (a.BillStatus.Equals("pending", System.StringComparison.OrdinalIgnoreCase) ||
                                a.BillStatus.Equals("unpaid", System.StringComparison.OrdinalIgnoreCase)))
                    .Select(a => new Bill
                    {
                        AppointmentId = a.AppointmentId,
                        DoctorName = a.DoctorName,
                        PatientName = a.PatientName,
                        StartTime = a.StartTime,
                        Duration = a.Duration,
                        Fee = a.Fee,
                        ClinicRoomNumber = a.ClinicRoomNumber,
                        BillStatus = a.BillStatus
                    });
            });
        }

     
        public Task<Bill?> GetBillByAppointmentIdAsync(int appointmentId)
        {
            return Task.Run(() =>
            {
                var appointment = _appointmentRepo.GetById(appointmentId);
                if (appointment == null ||
                    appointment.BillStatus == null ||
                    !(appointment.BillStatus.Equals("pending", System.StringComparison.OrdinalIgnoreCase) ||
                      appointment.BillStatus.Equals("unpaid", System.StringComparison.OrdinalIgnoreCase)))
                    return null;

                return new Bill
                {
                    AppointmentId = appointment.AppointmentId,
                    DoctorName = appointment.DoctorName,
                    PatientName = appointment.PatientName,
                    StartTime = appointment.StartTime,
                    Duration = appointment.Duration,
                    Fee = appointment.Fee,
                    ClinicRoomNumber = appointment.ClinicRoomNumber,
                    BillStatus = appointment.BillStatus
                };
            });
        }

      
        public Task<bool> MarkBillAsPaidAsync(int appointmentId)
        {
            return Task.Run(() =>
            {
                var appointment = _appointmentRepo.GetById(appointmentId);
                if (appointment == null ||
                    appointment.BillStatus == null ||
                    !(appointment.BillStatus.Equals("pending", System.StringComparison.OrdinalIgnoreCase) ||
                      appointment.BillStatus.Equals("unpaid", System.StringComparison.OrdinalIgnoreCase)))
                    return false;

                appointment.BillStatus = "Paid";
                _appointmentRepo.Update(appointment);
                return true;
            });
        }
    }
}

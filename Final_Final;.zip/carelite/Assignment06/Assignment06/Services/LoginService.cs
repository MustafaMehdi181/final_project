﻿using carelite.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace carelite.Services
{
    public interface ILoginService
    {
        Task<string?> ValidateUserAsync(string email, string password);
        string GenerateJwtToken(string email, string role);
        string GenerateRefreshToken();
        Task<(string newJwtToken, string newRefreshToken)?> RefreshTokensAsync(string email, string refreshToken);


    }

    public class LoginService : ILoginService
    {
        private readonly ILoginRepository _repository;
        private readonly IConfiguration _configuration;

        public LoginService(ILoginRepository repository, IConfiguration configuration)
        {
            _repository = repository;
            _configuration = configuration;
        }

        public async Task<string?> ValidateUserAsync(string email, string password)
        {
            return await _repository.ValidateUserAsync(email, password);
        }

        public string GenerateJwtToken(string email, string role)
        {
            var jwtSettings = _configuration.GetSection("Jwt");

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.Name, email),
                new Claim(JwtRegisteredClaimNames.Sub, email),
                new Claim(ClaimTypes.NameIdentifier, email),
                new Claim(ClaimTypes.Role, role),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };
            var expiryMinutes = double.Parse(jwtSettings["ExpiryMinutes"]);
            var token = new JwtSecurityToken(
                issuer: jwtSettings["Issuer"],
                audience: jwtSettings["Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(expiryMinutes),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using var rng = System.Security.Cryptography.RandomNumberGenerator.Create();
            rng.GetBytes(randomNumber);
            return Convert.ToBase64String(randomNumber);
        }
        public async Task<(string newJwtToken, string newRefreshToken)?> RefreshTokensAsync(string email, string refreshToken)
        {
            var storedToken = await _repository.GetRefreshTokenAsync(email, refreshToken);
            if (storedToken == null || storedToken.IsRevoked || storedToken.ExpiryDate <= DateTime.UtcNow)
            {
                Console.WriteLine(DateTime.UtcNow + "           " + storedToken.ExpiryDate);
                return null;
            }
            // You may want to revoke the old refresh token here for security
            await _repository.RevokeRefreshTokenAsync(email, refreshToken);

            // Generate new tokens
            var role = await _repository.getRoleByUsername(email); // Get role without password? Consider storing role separately or querying users table
            if (role == null)
                return null;

            var newJwtToken = GenerateJwtToken(email, role);
            var newRefreshToken = GenerateRefreshToken();
            var refreshExpiryDays = int.Parse(_configuration.GetSection("Jwt")["RefreshExpiryMinutes"]);
            await _repository.SaveRefreshTokenAsync(email, newRefreshToken, DateTime.UtcNow.AddMinutes(refreshExpiryDays));

            return (newJwtToken, newRefreshToken);
        }


    }
}

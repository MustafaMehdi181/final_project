﻿using carelite.Models;
using carelite.Repositories;
using System.Threading.Tasks;

namespace carelite.Services
{
    public interface IRegisterService
    {
        Task<bool> RegisterAsync(RegisterModel register);
    }

    public class RegisterService : IRegisterService
    {
        private readonly IRegisterRepository _repository;

        public RegisterService(IRegisterRepository repository)
        {
            _repository = repository;
        }

        public async Task<bool> RegisterAsync(RegisterModel register)
        {
            // Check if user already exists
            if (await _repository.UserExistsAsync(register.Email))
                return false;

            await _repository.RegisterAsync(register);
            return true;
        }
    }
}

﻿using System.Net.Mail;

namespace carelite.Services
{
    public interface INotificationService
    {
        Task? sendAppointmentNotification(int id);
    }
    public class NotificationService : INotificationService
    {
        private readonly AppointmentService _appointmentService;
        private readonly PatientService _patientService;

        private readonly string senderAddress = "mustafa.mehdi@curemd.com";
        private readonly string senderName = "CareLite";

        public NotificationService(AppointmentService appointmentService,PatientService patientService)
        {
            _appointmentService = appointmentService;
            _patientService = patientService;
       
        }

        public async Task? sendAppointmentNotification(int id)
        {
            var appointment =  _appointmentService.GetAppointmentById(id);
            if (appointment == null) return;

            var patient = await _patientService.GetByIdAsync(appointment.PatientName);

            if (patient == null) return;

            if (string.IsNullOrEmpty(patient.Email)) return;

            using var message = new MailMessage
            {
                From = new MailAddress(senderAddress, senderName),
                Subject = "Appointment Schedule",
                Body = $@"Hello {appointment.PatientName},

We hope this message finds you well.

This email is to inform you that your appointment has been scheduled:

📅 Date/Time: {appointment.StartTime:f}
⏱ Duration: {appointment.Duration} minutes
👩‍⚕️ Doctor: {appointment.DoctorName}
🧑‍🤝‍🧑 Patient: {appointment.PatientName}
🏥 Room: {appointment.ClinicRoomNumber}

Looking forward to seeing you.

Regards,
CareLite Team"
            };

            message.To.Add(patient.Email);

            using var smtp = new SmtpClient("sendmail.curemd.com", 25)
            {
                UseDefaultCredentials = true,
                DeliveryMethod = SmtpDeliveryMethod.Network
            };

            await smtp.SendMailAsync(message);
        }
    }
}

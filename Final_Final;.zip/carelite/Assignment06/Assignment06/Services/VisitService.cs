﻿using carelite.Models;
using carelite.Repositories;


namespace carelite.Services
{
    public class AppointmentService
    {
        private readonly AppointmentRepository _repository;

        public AppointmentService(AppointmentRepository repository)
        {
            _repository = repository;
        }

        public IEnumerable<AppointmentInfo> GetAllAppointments() => _repository.GetAll();

        public AppointmentInfo? GetAppointmentById(int id) => _repository.GetById(id);

        public int CreateAppointment(AppointmentInfo appointment)
        {
            ValidateBusinessRules(appointment);
            return _repository.Add(appointment);
        }

        public bool UpdateAppointment(AppointmentInfo appointment)
        {
            ValidateBusinessRules(appointment, isUpdate: true);
            return _repository.Update(appointment);
        }

        public bool DeleteAppointment(int id) => _repository.Delete(id);

        private void ValidateBusinessRules(AppointmentInfo appointment, bool isUpdate = false)
        {
            var appointments = _repository.GetAll().ToList();
            DateTime newEnd = appointment.StartTime.AddMinutes(appointment.Duration);

            
            if (appointments.Any(a =>
                a.PatientName == appointment.PatientName &&
                a.DoctorName == appointment.DoctorName &&
                Math.Abs((a.StartTime - appointment.StartTime).TotalHours) < 24 &&
                (!isUpdate || a.AppointmentId != appointment.AppointmentId)))
            {
                throw new Exception("Patient already has an appointment with this doctor within 24 hours.");
            }

            
            if (appointments.Any(a =>
                a.DoctorName == appointment.DoctorName &&
                (!isUpdate || a.AppointmentId != appointment.AppointmentId) &&
                appointment.StartTime < a.StartTime.AddMinutes(a.Duration) &&
                newEnd > a.StartTime))
            {
                throw new Exception("Appointment time overlaps with another appointment for this doctor.");
            }

            
            if (appointment.StartTime.Hour < 9 || newEnd.Hour > 18 ||
                (newEnd.Hour == 18 && newEnd.Minute > 0))
            {
                throw new Exception("Appointment must be scheduled within clinic hours (9 AM - 6 PM).");
            }
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using carelite.Models;
using carelite.Services;
using Microsoft.AspNetCore.Authorization;

namespace carelite.Controllers
{
    [ApiController]
    [AllowAnonymous]
    [Route("api/[controller]")]
    public class PatientsController : ControllerBase
    {
        private readonly PatientService _service;

        public PatientsController(PatientService service)
        {
            _service = service;
        }

        
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Patient>>> GetAll()
        {
            var patients = await _service.GetAllAsync();
            return Ok(patients);
        }

        [HttpGet("{username}")]
        public async Task<ActionResult<Patient>> GetById(string username)
        {
            var patient = await _service.GetByIdAsync(username);
            if (patient == null)
                return NotFound(new { Message = $"Patient with ID {username} not found." });

            return Ok(patient);
        }

     
        [HttpPost]
        public async Task<IActionResult> Add([FromBody] Patient patient)
        {
            if (!ModelState.IsValid)  
                return BadRequest(ModelState);

            await _service.AddAsync(patient);
            return CreatedAtAction(nameof(GetById), new { id = patient.PatientId }, patient);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Patient patient)
        {
            if (id != patient.PatientId)
                return BadRequest("Patient ID mismatch.");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _service.UpdateAsync(patient);
            return Ok(new { Message = "Patient updated successfully" });
        }

        
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);
            return Ok(new { Message = "Patient deleted successfully" });
        }
    }
}

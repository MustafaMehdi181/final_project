﻿using Microsoft.AspNetCore.Mvc;
using carelite.Models;
using carelite.Services;
using Microsoft.AspNetCore.Authorization;

namespace carelite.Controllers
{
    [ApiController]
    [Authorize(Roles = "admin")]
    [Route("api/[controller]")]


    public class DoctorsController : ControllerBase
    {
        private readonly DoctorService _service;

        public DoctorsController(DoctorService service)
        {
            _service = service;
        }

        
        [HttpGet]
        
  
        public async Task<ActionResult<IEnumerable<Doctor>>> GetAll()
        {
            var doctors = await _service.GetAllAsync();
            return Ok(doctors);
        }

        [HttpGet("{id}")]
       
        public async Task<ActionResult<Doctor>> GetById(int id)
        {
            var doctor = await _service.GetByIdAsync(id);
            if (doctor == null)
                return NotFound(new { Message = $"Doctor with ID {id} not found." });

            return Ok(doctor);
        }

        [HttpPost]
       
        public async Task<IActionResult> Add([FromBody] Doctor doctor)
        {
            if (!ModelState.IsValid) 
                return BadRequest(ModelState);

            await _service.AddAsync(doctor);
            return CreatedAtAction(nameof(GetById), new { id = doctor.DoctorId }, doctor);
        }

        [HttpPut("{id}")]
       
        public async Task<IActionResult> Update(int id, [FromBody] Doctor doctor)
        {
            if (id != doctor.DoctorId)
                return BadRequest("Doctor ID mismatch.");

            if (!ModelState.IsValid)  
                return BadRequest(ModelState);

            await _service.UpdateAsync(doctor);
            return Ok(new { Message = "Doctor updated successfully" });
        }

        
        [HttpDelete("{id}")]
       
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);
            return Ok(new { Message = "Doctor deleted successfully" });
        }
    }
}

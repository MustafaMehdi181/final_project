﻿using carelite.Models;
using carelite.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace carelite.Controllers
{
    [ApiController]
    [Authorize (Roles = "admin")]
    [Route("api/[controller]")]
    public class RegisterController : ControllerBase
    {
        private readonly IRegisterService _service;

        public RegisterController(IRegisterService service)
        {
            _service = service;
        }

        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register([FromBody] RegisterModel register)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var success = await _service.RegisterAsync(register);
            if (!success)
                return Conflict(new { Message = "User with this email already exists." });

            return Ok(new { Message = "User registered successfully." });
        }
    }
}

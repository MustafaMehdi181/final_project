﻿using Microsoft.AspNetCore.Mvc;
using carelite.Models;
using carelite.Services;
using Microsoft.AspNetCore.Authorization;

namespace carelite.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [AllowAnonymous]
    public class VisitTypesController : ControllerBase
    {
        private readonly VisitTypeService _service;

        public VisitTypesController(VisitTypeService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var visitTypes = await _service.GetAllAsync();
            return Ok(visitTypes);
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromBody] VisitType visitType)
        {
            if (visitType == null) return BadRequest("VisitType data is required.");

            await _service.AddAsync(visitType);
            return Ok(new { Message = "Visit type added successfully." });
        }
    }
}

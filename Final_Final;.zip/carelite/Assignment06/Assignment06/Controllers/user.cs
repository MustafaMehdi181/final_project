﻿using carelite.Models;
using carelite.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using carelite.Repositories;

namespace carelite.Controllers
{
    [ApiController]
    [AllowAnonymous]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly ILoginService _service;
        private readonly IConfiguration _configuration;
        private readonly ILoginRepository _repository;

        public UserController(ILoginService service, IConfiguration configuration , ILoginRepository repository)
        {
            _service = service;
            _configuration = configuration;
            _repository = repository;
        }

        [HttpPost("refresh-token")]
        [AllowAnonymous]
        public async Task<IActionResult> RefreshToken([FromBody] RefreshRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.Email) || string.IsNullOrEmpty(request.RefreshToken))
                return BadRequest(new { Message = "Invalid client request" });

            var tokens = await _service.RefreshTokensAsync(request.Email, request.RefreshToken);

            if (tokens == null)
                return Unauthorized(new { Message = "Invalid refresh token or token expired" });

            // unwrap nullable tuple before accessing properties
            return Ok(new { Token = tokens.Value.newJwtToken, RefreshToken = tokens.Value.newRefreshToken });
        }



        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] LoginDetail login)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var role = await _service.ValidateUserAsync(login.Email, login.Password);

            if (!string.IsNullOrEmpty(role))
            {
                var token = _service.GenerateJwtToken(login.Email, role);
                var refreshToken = _service.GenerateRefreshToken();

                // Save refresh token to database
                var refreshExpiryDays = int.Parse(_configuration.GetSection("Jwt")["RefreshExpiryMinutes"]);
                await _repository.SaveRefreshTokenAsync(login.Email, refreshToken, DateTime.UtcNow.AddMinutes(refreshExpiryDays));

                return Ok(new { Token = token, RefreshToken = refreshToken, Role = role });
            }

            return Unauthorized(new { Message = "Invalid email or password." });
        }
        [HttpGet("profile")]
        [Authorize]
        public IActionResult GetProfile()
        {
            var email = User.FindFirstValue(ClaimTypes.NameIdentifier)
                        ?? User.FindFirstValue(JwtRegisteredClaimNames.Sub);

            var role = User.FindFirstValue(ClaimTypes.Role) ?? "Unknown";

            return Ok(new { Email = email, Role = role, Message = "You are authorized!" });
        }

        private string GenerateJwtToken(string email, string role)
        {
            var jwtSettings = _configuration.GetSection("Jwt");

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.Name, email),
                new Claim(JwtRegisteredClaimNames.Sub, email),
                new Claim(ClaimTypes.NameIdentifier, email),
                new Claim(ClaimTypes.Role, role),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var token = new JwtSecurityToken(
                issuer: jwtSettings["Issuer"],
                audience: jwtSettings["Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(Convert.ToDouble(jwtSettings["ExpiryMinutes"])),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public class RefreshRequest
        {
            public string Email { get; set; } = string.Empty;
            public string RefreshToken { get; set; } = string.Empty;
        }

    }
}

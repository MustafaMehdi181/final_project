﻿using System.Data.SqlClient;
using carelite.Models;

namespace carelite.Repositories
{
    public class ApiLogRepository
    {
        private readonly string _connectionString;

        public ApiLogRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task AddLogAsync(ApiLog log)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(@"
                    INSERT INTO ApiLogs (UserName, HttpMethod, RequestPath, StatusCode, Success, Timestamp)
                    VALUES (@UserName, @HttpMethod, @RequestPath, @StatusCode, @Success, @Timestamp)", conn);

                cmd.Parameters.AddWithValue("@UserName", (object?)log.UserName ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@HttpMethod", log.HttpMethod);
                cmd.Parameters.AddWithValue("@RequestPath", log.RequestPath);
                cmd.Parameters.AddWithValue("@StatusCode", log.StatusCode);
                cmd.Parameters.AddWithValue("@Success", log.Success);
                cmd.Parameters.AddWithValue("@Timestamp", log.Timestamp);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }
    }
}

﻿using carelite.Models;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace carelite.Repositories
{
    public interface ILoginRepository
    {
        Task SaveRefreshTokenAsync(string email, string refreshToken, DateTime expiry);
        Task<string?> ValidateUserAsync(string email, string password);

        Task<RefreshToken?> GetRefreshTokenAsync(string email, string refreshToken);

        Task RevokeRefreshTokenAsync(string email, string refreshToken);

        Task<string?> getRoleByUsername(string email);
    }

    public class LoginRepository : ILoginRepository
    {
        private readonly string _connectionString;

        public LoginRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<string?> ValidateUserAsync(string email, string password)
        {
            using SqlConnection conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            string query = "SELECT role FROM LoginDetail WHERE email = @Email AND password = @Password";
            using SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Password", password);

            var role = await cmd.ExecuteScalarAsync();
            return role as string;
        }

        public async Task<string?> getRoleByUsername(string email)
        {
            using SqlConnection conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            string query = "SELECT role FROM LoginDetail WHERE email = @Email";
            using SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", email);

            var role = await cmd.ExecuteScalarAsync();
            return role as string;

        }
        public async Task SaveRefreshTokenAsync(string email, string refreshToken, DateTime expiry)
        {
            using SqlConnection conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            string query = "INSERT INTO RefreshTokens (Email, Token, ExpiryDate, IsRevoked) VALUES (@Email, @Token, @ExpiryDate, 0)";
            using SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Token", refreshToken);
            cmd.Parameters.AddWithValue("@ExpiryDate", expiry);

            await cmd.ExecuteNonQueryAsync();
        }

        public async Task<RefreshToken?> GetRefreshTokenAsync(string email, string refreshToken)
        {
            using SqlConnection conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            string query = "SELECT Id, Email, Token, ExpiryDate, IsRevoked FROM RefreshTokens WHERE Email = @Email AND Token = @Token";
            using SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Token", refreshToken);

            using var reader = await cmd.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return new RefreshToken
                {
                    Id = reader.GetInt32(0),
                    Email = reader.GetString(1),
                    Token = reader.GetString(2),
                    ExpiryDate = reader.GetDateTime(3),
                    IsRevoked = reader.GetBoolean(4)
                };
            }
            return null;
        }

        public async Task RevokeRefreshTokenAsync(string email, string refreshToken)
        {
            using SqlConnection conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            string query = "UPDATE RefreshTokens SET IsRevoked = 1 WHERE Email = @Email AND Token = @Token";
            using SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Token", refreshToken);

            await cmd.ExecuteNonQueryAsync();
        }



    }
}

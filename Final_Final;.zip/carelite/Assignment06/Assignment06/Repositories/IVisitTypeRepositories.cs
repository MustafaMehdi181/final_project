﻿using carelite.Models;

public interface IVisitTypeRepository
{
    Task<IEnumerable<VisitType>> GetAllAsync();
    Task AddAsync(VisitType visitType);
}

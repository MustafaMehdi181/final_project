﻿using carelite.Models;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace carelite.Repositories
{
    public interface IRegisterRepository
    {
        Task RegisterAsync(RegisterModel register);
        Task<bool> UserExistsAsync(string email);
    }

    public class RegisterRepository : IRegisterRepository
    {
        private readonly string _connectionString;

        public RegisterRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task RegisterAsync(RegisterModel register)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                var query = "INSERT INTO LoginDetail (email, password, role) VALUES (@Email, @Password, @Role)";
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", register.Email);
                    cmd.Parameters.AddWithValue("@Password", register.Password);
                    cmd.Parameters.AddWithValue("@Role", register.Role ?? "User"); // Default role if null

                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task<bool> UserExistsAsync(string email)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                var query = "SELECT COUNT(*) FROM LoginDetail WHERE email = @Email";
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    int count = (int)await cmd.ExecuteScalarAsync();
                    return count > 0;
                }
            }
        }
    }
}

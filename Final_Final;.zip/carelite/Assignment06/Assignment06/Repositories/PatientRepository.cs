﻿using System.Data.SqlClient;
using   carelite.Models;

namespace carelite.Repositories
{
    public class PatientRepository : IPatientRepository
    {
        private readonly string _connectionString;

        public PatientRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<IEnumerable<Patient>> GetAllAsync()
        {
            var patients = new List<Patient>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Patients", conn);
                await conn.OpenAsync();
                SqlDataReader reader = await cmd.ExecuteReaderAsync();

                while (await reader.ReadAsync())
                {
                    patients.Add(new Patient
                    {
                        PatientId = (int)reader["PatientId"],
                        PatientName = reader["PatientName"].ToString(),
                        PatientPhone = reader["PatientPhone"].ToString(),
                        Email = reader["Email"].ToString()
                    });
                }
            }
            return patients;
        }

        public async Task<Patient?> GetByIdAsync(string username)
        {
            Patient? patient = null;

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Patients WHERE PatientName = @PatientName", conn);
                cmd.Parameters.AddWithValue("@PatientName", username);
                await conn.OpenAsync();
                SqlDataReader reader = await cmd.ExecuteReaderAsync();

                if (await reader.ReadAsync())
                {
                    patient = new Patient
                    {
                        PatientId = (int)reader["PatientId"],
                        PatientName = reader["PatientName"].ToString(),
                        PatientPhone = reader["PatientPhone"].ToString(),
                        Email = reader["Email"].ToString()
                    };
                }
            }
            return patient;
        }

        public async Task AddAsync(Patient patient)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Patients (PatientName, PatientPhone) VALUES (@Name, @Phone)", conn);
                cmd.Parameters.AddWithValue("@Name", patient.PatientName);
                cmd.Parameters.AddWithValue("@Phone", patient.PatientPhone);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task UpdateAsync(Patient patient)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    "UPDATE Patients SET PatientName = @Name, PatientPhone = @Phone WHERE PatientId = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", patient.PatientId);
                cmd.Parameters.AddWithValue("@Name", patient.PatientName);
                cmd.Parameters.AddWithValue("@Phone", patient.PatientPhone);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task DeleteAsync(int id)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Patients WHERE PatientId = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }
    }
}

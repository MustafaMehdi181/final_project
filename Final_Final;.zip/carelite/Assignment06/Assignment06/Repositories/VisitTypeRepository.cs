﻿using System.Data.SqlClient;
using carelite.Models;

namespace carelite.Repositories
{
    public class VisitTypeRepository : IVisitTypeRepository
    {
        private readonly string _connectionString;

        public VisitTypeRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<IEnumerable<VisitType>> GetAllAsync()
        {
            var visitTypes = new List<VisitType>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM VisitTypes", conn);
                await conn.OpenAsync();
                SqlDataReader reader = await cmd.ExecuteReaderAsync();

                while (await reader.ReadAsync())
                {
                    visitTypes.Add(new VisitType
                    {
                        VisitTypeId = (int)reader["VisitTypeId"],
                        VisitTypeName = reader["VisitTypeName"].ToString(),
                        Fee = (decimal)reader["Fee"]
                    });
                }
            }
            return visitTypes;
        }

        public async Task AddAsync(VisitType visitType)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO VisitTypes (VisitTypeName, Fee) VALUES (@Name, @Fee)", conn);
                cmd.Parameters.AddWithValue("@Name", visitType.VisitTypeName);
                cmd.Parameters.AddWithValue("@Fee", visitType.Fee);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }
    }
}

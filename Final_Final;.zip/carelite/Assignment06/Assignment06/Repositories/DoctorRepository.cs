﻿using System.Data.SqlClient;
using carelite.Models;

namespace carelite.Repositories
{
    public class DoctorRepository : IDoctorRepository
    {
        private readonly string _connectionString;

        public DoctorRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<IEnumerable<Doctor>> GetAllAsync()
        {
            var doctors = new List<Doctor>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Doctors", conn);
                await conn.OpenAsync();
                SqlDataReader reader = await cmd.ExecuteReaderAsync();

                while (await reader.ReadAsync())
                {
                    doctors.Add(new Doctor
                    {
                        DoctorId = (int)reader["DoctorId"],
                        DoctorName = reader["DoctorName"].ToString(),
                        DoctorSpecialty = reader["DoctorSpecialty"].ToString()
                    });
                }
            }
            return doctors;
        }

        public async Task<Doctor?> GetByIdAsync(int id)
        {
            Doctor? doctor = null;

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Doctors WHERE DoctorId = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);
                await conn.OpenAsync();
                SqlDataReader reader = await cmd.ExecuteReaderAsync();

                if (await reader.ReadAsync())
                {
                    doctor = new Doctor
                    {
                        DoctorId = (int)reader["DoctorId"],
                        DoctorName = reader["DoctorName"].ToString(),
                        DoctorSpecialty = reader["DoctorSpecialty"].ToString()
                    };
                }
            }
            return doctor;
        }

        public async Task AddAsync(Doctor doctor)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Doctors (DoctorName, DoctorSpecialty) VALUES (@Name, @Specialty)", conn);
                cmd.Parameters.AddWithValue("@Name", doctor.DoctorName);
                cmd.Parameters.AddWithValue("@Specialty", doctor.DoctorSpecialty);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task UpdateAsync(Doctor doctor)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    "UPDATE Doctors SET DoctorName = @Name, DoctorSpecialty = @Specialty WHERE DoctorId = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", doctor.DoctorId);
                cmd.Parameters.AddWithValue("@Name", doctor.DoctorName);
                cmd.Parameters.AddWithValue("@Specialty", doctor.DoctorSpecialty);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task DeleteAsync(int id)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Doctors WHERE DoctorId = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }
    }
}

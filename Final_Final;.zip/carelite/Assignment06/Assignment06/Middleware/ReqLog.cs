﻿using System.Security.Claims;
using carelite.Repositories;
using carelite.Models;

namespace carelite.Middleware
{
    public class RequestLoggingMiddleware
    {
        private readonly RequestDelegate _next;

        public RequestLoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context, ApiLogRepository logRepo)
        {
      
            string method = context.Request.Method;
            string path = context.Request.Path;

            await _next(context); 

            int statusCode = context.Response.StatusCode;
            bool success = statusCode >= 200 && statusCode < 300;
            Console.WriteLine(context.User.FindFirst("username"));
            Console.WriteLine(context.Request.Headers["Authorization"].ToString());
         
            var userName=context.User.FindFirst("username")?.Value ?? "Guest";
            var log = new ApiLog
            {
                UserName = userName,
                HttpMethod = method,
                RequestPath = path,
                StatusCode = statusCode,
                Success = success,
                Timestamp = DateTime.Now
            };

            await logRepo.AddLogAsync(log);
        }
    }

    
}
